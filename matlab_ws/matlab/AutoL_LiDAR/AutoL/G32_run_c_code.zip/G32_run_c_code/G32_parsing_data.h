/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: G32_parsing_data.h
 *
 * MATLAB Coder version            : 24.1
 * C/C++ source code generated on  : 29-Jul-2024 11:53:30
 */

#ifndef G32_PARSING_DATA_H
#define G32_PARSING_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern bool isInitialized_G32_parsing;

#endif
/*
 * File trailer for G32_parsing_data.h
 *
 * [EOF]
 */
